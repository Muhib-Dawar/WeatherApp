package com.example.weatherapp.presentation.screens.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.weatherapp.WeatherApplication
import com.example.weatherapp.presentation.navigation.Screen
import com.example.weatherapp.presentation.viewmodel.SearchViewModel

@Composable
fun SearchScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val app = context.applicationContext as WeatherApplication
    val viewModel: SearchViewModel = viewModel {
        SearchViewModel(app.di.repository)
    }
    
    val searchQuery by viewModel.searchQuery
    val favorites by viewModel.favoriteCities.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search City") },
            trailingIcon = {
                IconButton(onClick = {
                    if (searchQuery.isNotBlank()) {
                        navController.navigate(Screen.Detail.createRoute(searchQuery))
                    }
                }) {
                    Icon(Icons.Default.Search, contentDescription = "Search")
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Favorite Cities", style = MaterialTheme.typography.titleLarge)

        LazyColumn {
            items(favorites) { city ->
                ListItem(
                    headlineContent = { Text(city.cityName) },
                    supportingContent = { Text(city.country) },
                    modifier = Modifier.clickable {
                        navController.navigate(Screen.Detail.createRoute(city.cityName))
                    }
                )
            }
        }
    }
}
