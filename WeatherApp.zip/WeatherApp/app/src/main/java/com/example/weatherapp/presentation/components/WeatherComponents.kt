package com.example.weatherapp.presentation.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.weatherapp.data.remote.WeatherResponse
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

@Composable
fun WeatherCard(weather: WeatherResponse) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.2f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = MaterialTheme.shapes.extraLarge
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = weather.cityName,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Text(
                text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(weather.dt * 1000)),
                fontSize = 16.sp,
                color = Color.White.copy(alpha = 0.7f)
            )

            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                AsyncImage(
                    model = "https://openweathermap.org/img/wn/${weather.weather[0].icon}@4x.png",
                    contentDescription = null,
                    modifier = Modifier.size(120.dp)
                )
                
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "${weather.main.temp.roundToInt()}°",
                        fontSize = 72.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = weather.weather[0].description.replaceFirstChar { it.uppercase() },
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            
            HorizontalDivider(color = Color.White.copy(alpha = 0.2f), thickness = 1.dp)
            
            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                WeatherInfoItem(
                    label = "Wind",
                    value = "${weather.wind.speed} m/s",
                    icon = Icons.Default.Air
                )
                WeatherInfoItem(
                    label = "Humidity",
                    value = "${weather.main.humidity}%",
                    icon = Icons.Default.WaterDrop
                )
                WeatherInfoItem(
                    label = "Pressure",
                    value = "${weather.main.pressure} hPa",
                    icon = Icons.Default.Compress
                )
                WeatherInfoItem(
                    label = "Feels Like",
                    value = "${weather.main.feelsLike.roundToInt()}°",
                    icon = Icons.Default.Thermostat
                )
            }
        }
    }
}

@Composable
fun WeatherInfoItem(label: String, value: String, icon: ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.7f),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(text = label, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
    }
}

@Composable
fun ForecastItem(forecast: com.example.weatherapp.data.remote.ForecastItem) {
    Card(
        modifier = Modifier
            .width(100.dp)
            .padding(horizontal = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)),
        shape = MaterialTheme.shapes.large
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).parse(forecast.dtTxt)
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(date ?: Date())
            
            Text(
                text = time,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            AsyncImage(
                model = "https://openweathermap.org/img/wn/${forecast.weather[0].icon}.png",
                contentDescription = null,
                modifier = Modifier.size(40.dp)
            )
            Text(
                text = "${forecast.main.temp.roundToInt()}°",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.White
            )
        }
    }
}
