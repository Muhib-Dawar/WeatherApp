package com.example.weatherapp.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [FavoriteCityEntity::class], version = 1, exportSchema = false)
abstract class WeatherDatabase : RoomDatabase() {
    abstract val favoriteCityDao: FavoriteCityDao

    companion object {
        const val DATABASE_NAME = "weather_db"
    }
}
