package com.example.weatherapp.presentation.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.data.local.FavoriteCityEntity
import com.example.weatherapp.data.remote.ForecastResponse
import com.example.weatherapp.data.remote.WeatherResponse
import com.example.weatherapp.data.repository.WeatherRepository
import com.example.weatherapp.util.Resource
import kotlinx.coroutines.launch

class DetailViewModel(
    private val repository: WeatherRepository,
    private val cityName: String
) : ViewModel() {

    private val _weatherState = mutableStateOf<Resource<WeatherResponse>>(Resource.Loading())
    val weatherState: State<Resource<WeatherResponse>> = _weatherState

    private val _forecastState = mutableStateOf<Resource<ForecastResponse>>(Resource.Loading())
    val forecastState: State<Resource<ForecastResponse>> = _forecastState

    private val _isFavorite = mutableStateOf(false)
    val isFavorite: State<Boolean> = _isFavorite

    private val apiKey = "403c3afebd0f25364ac507c5409a81d8"

    init {
        getWeatherData()
        checkIfFavorite()
    }

    private fun getWeatherData() {
        viewModelScope.launch {
            _weatherState.value = Resource.Loading()
            _forecastState.value = Resource.Loading()

            _weatherState.value = repository.getCurrentWeather(cityName, apiKey)
            _forecastState.value = repository.getForecast(cityName, apiKey)
        }
    }

    private fun checkIfFavorite() {
        viewModelScope.launch {
            _isFavorite.value = repository.isCityFavorite(cityName)
        }
    }

    fun toggleFavorite(country: String) {
        viewModelScope.launch {
            if (_isFavorite.value) {
                repository.removeFavoriteCity(FavoriteCityEntity(cityName, country))
            } else {
                repository.addFavoriteCity(FavoriteCityEntity(cityName, country))
            }
            _isFavorite.value = !_isFavorite.value
        }
    }
}
