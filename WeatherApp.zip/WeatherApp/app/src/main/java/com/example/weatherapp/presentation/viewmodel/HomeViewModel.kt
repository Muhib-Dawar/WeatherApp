package com.example.weatherapp.presentation.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.data.remote.ForecastResponse
import com.example.weatherapp.data.remote.WeatherResponse
import com.example.weatherapp.data.repository.WeatherRepository
import com.example.weatherapp.util.Resource
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repository: WeatherRepository
) : ViewModel() {

    private val _weatherState = mutableStateOf<Resource<WeatherResponse>>(Resource.Loading())
    val weatherState: State<Resource<WeatherResponse>> = _weatherState

    private val _forecastState = mutableStateOf<Resource<ForecastResponse>>(Resource.Loading())
    val forecastState: State<Resource<ForecastResponse>> = _forecastState

    private val apiKey = "403c3afebd0f25364ac507c5409a81d8"

    fun getWeatherData(lat: Double, lon: Double) {
        viewModelScope.launch {
            _weatherState.value = Resource.Loading()
            _forecastState.value = Resource.Loading()
            
            _weatherState.value = repository.getCurrentWeatherByLocation(lat, lon, apiKey)
            _forecastState.value = repository.getForecastByLocation(lat, lon, apiKey)
        }
    }

    fun getWeatherDataByCity(cityName: String) {
        viewModelScope.launch {
            _weatherState.value = Resource.Loading()
            _forecastState.value = Resource.Loading()

            _weatherState.value = repository.getCurrentWeather(cityName, apiKey)
            _forecastState.value = repository.getForecast(cityName, apiKey)
        }
    }
}
