package com.example.weatherapp

import android.app.Application
import com.example.weatherapp.di.ManualDI

class WeatherApplication : Application() {
    lateinit var di: ManualDI
        private set

    override fun onCreate() {
        super.onCreate()
        di = ManualDI(this)
    }
}
