package com.example.weatherapp.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

@Composable
fun WeatherBackground(
    weatherCondition: String?,
    content: @Composable () -> Unit
) {
    val colors = when (weatherCondition?.lowercase()) {
        "clear" -> listOf(Color(0xFF4facfe), Color(0xFF00f2fe)) // Light Blue
        "clouds" -> listOf(Color(0xFFbdc3c7), Color(0xFF2c3e50)) // Grayish
        "rain", "drizzle" -> listOf(Color(0xFF4b6cb7), Color(0xFF182848)) // Dark Blue
        "thunderstorm" -> listOf(Color(0xFF0f0c29), Color(0xFF302b63), Color(0xFF24243e)) // Deep Purple/Black
        "snow" -> listOf(Color(0xFFe6e9f0), Color(0xFFeef1f5)) // Whiteish Blue
        else -> listOf(Color(0xFF6a11cb), Color(0xFF2575fc)) // Default Indigo/Purple
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors))
    ) {
        content()
    }
}
