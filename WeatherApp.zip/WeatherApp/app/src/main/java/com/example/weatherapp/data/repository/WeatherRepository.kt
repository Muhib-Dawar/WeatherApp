package com.example.weatherapp.data.repository

import android.util.Log
import com.example.weatherapp.data.local.FavoriteCityDao
import com.example.weatherapp.data.local.FavoriteCityEntity
import com.example.weatherapp.data.remote.ForecastResponse
import com.example.weatherapp.data.remote.WeatherApi
import com.example.weatherapp.data.remote.WeatherResponse
import com.example.weatherapp.util.Resource
import kotlinx.coroutines.flow.Flow

class WeatherRepository(
    private val api: WeatherApi,
    private val dao: FavoriteCityDao
) {
    suspend fun getCurrentWeather(cityName: String, apiKey: String): Resource<WeatherResponse> {
        return try {
            val response = api.getCurrentWeather(cityName, apiKey)
            Log.d("WeatherRepository", "getCurrentWeather Success: ${response.cityName}")
            Resource.Success(response)
        } catch (e: Exception) {
            Log.e("WeatherRepository", "getCurrentWeather Error: ${e.message}")
            Resource.Error(e.message ?: "An unknown error occurred")
        }
    }

    suspend fun getCurrentWeatherByLocation(lat: Double, lon: Double, apiKey: String): Resource<WeatherResponse> {
        return try {
            val response = api.getCurrentWeatherByLocation(lat, lon, apiKey)
            Log.d("WeatherRepository", "getCurrentWeatherByLoc Success: ${response.cityName}")
            Resource.Success(response)
        } catch (e: Exception) {
            Log.e("WeatherRepository", "getCurrentWeatherByLoc Error: ${e.message}")
            Resource.Error(e.message ?: "An unknown error occurred")
        }
    }

    suspend fun getForecast(cityName: String, apiKey: String): Resource<ForecastResponse> {
        return try {
            val response = api.getForecast(cityName, apiKey)
            Log.d("WeatherRepository", "getForecast Success: ${response.city.name}")
            Resource.Success(response)
        } catch (e: Exception) {
            Log.e("WeatherRepository", "getForecast Error: ${e.message}")
            Resource.Error(e.message ?: "An unknown error occurred")
        }
    }

    suspend fun getForecastByLocation(lat: Double, lon: Double, apiKey: String): Resource<ForecastResponse> {
        return try {
            val response = api.getForecastByLocation(lat, lon, apiKey)
            Log.d("WeatherRepository", "getForecastByLoc Success: ${response.city.name}")
            Resource.Success(response)
        } catch (e: Exception) {
            Log.e("WeatherRepository", "getForecastByLoc Error: ${e.message}")
            Resource.Error(e.message ?: "An unknown error occurred")
        }
    }

    fun getFavoriteCities(): Flow<List<FavoriteCityEntity>> = dao.getAllFavoriteCities()

    suspend fun addFavoriteCity(city: FavoriteCityEntity) = dao.insertCity(city)

    suspend fun removeFavoriteCity(city: FavoriteCityEntity) = dao.deleteCity(city)

    suspend fun isCityFavorite(cityName: String): Boolean = dao.isCityFavorite(cityName)
}
