package com.example.weatherapp.presentation.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash_screen")
    object Home : Screen("home_screen")
    object Search : Screen("search_screen")
    object Detail : Screen("detail_screen/{cityName}") {
        fun createRoute(cityName: String) = "detail_screen/$cityName"
    }
    object Favorites : Screen("favorites_screen")
}
