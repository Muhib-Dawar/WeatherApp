package com.example.weatherapp.presentation.screens.home

import android.Manifest
import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.weatherapp.WeatherApplication
import com.example.weatherapp.presentation.components.ForecastItem
import com.example.weatherapp.presentation.components.WeatherCard
import com.example.weatherapp.presentation.navigation.Screen
import com.example.weatherapp.presentation.viewmodel.HomeViewModel
import com.example.weatherapp.util.Resource
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.android.gms.location.LocationServices

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Refresh
import com.example.weatherapp.presentation.components.WeatherBackground
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource

@OptIn(ExperimentalPermissionsApi::class)
@SuppressLint("MissingPermission")
@Composable
fun HomeScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val app = context.applicationContext as WeatherApplication
    val viewModel: HomeViewModel = viewModel {
        HomeViewModel(app.di.repository)
    }
    
    val weatherState by viewModel.weatherState
    val forecastState by viewModel.forecastState
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    
    val locationPermissionState = rememberPermissionState(
        permission = Manifest.permission.ACCESS_FINE_LOCATION
    )

    val fetchWeatherWithLocation = {
        val priority = Priority.PRIORITY_HIGH_ACCURACY
        fusedLocationClient.getCurrentLocation(priority, CancellationTokenSource().token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    viewModel.getWeatherData(location.latitude, location.longitude)
                } else {
                    viewModel.getWeatherDataByCity("London")
                }
            }
            .addOnFailureListener {
                viewModel.getWeatherDataByCity("London")
            }
    }

    LaunchedEffect(key1 = locationPermissionState.status.isGranted) {
        if (locationPermissionState.status.isGranted) {
            fetchWeatherWithLocation()
        } else {
            locationPermissionState.launchPermissionRequest()
        }
    }

    WeatherBackground(weatherCondition = weatherState.data?.weather?.firstOrNull()?.main) {
        Scaffold(
            containerColor = Color.Transparent,
            floatingActionButton = {
                Column {
                    FloatingActionButton(
                        onClick = { fetchWeatherWithLocation() },
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                    FloatingActionButton(onClick = { navController.navigate(Screen.Search.route) }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                if (!locationPermissionState.status.isGranted) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Card(
                            modifier = Modifier.padding(32.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.2f))
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Location access needed", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Please allow location access to see local weather data.", color = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(onClick = { locationPermissionState.launchPermissionRequest() }) {
                                    Text("Grant Permission")
                                }
                            }
                        }
                    }
                } else {
                    when (weatherState) {
                        is Resource.Loading -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Color.White)
                            }
                        }
                        is Resource.Success -> {
                            weatherState.data?.let { weather ->
                                WeatherCard(weather = weather)
                                
                                Spacer(modifier = Modifier.height(24.dp))
                                
                                Text(
                                    text = "5-Day Forecast",
                                    modifier = Modifier.padding(horizontal = 24.dp),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                when (forecastState) {
                                    is Resource.Success -> {
                                        LazyRow(
                                            modifier = Modifier.fillMaxWidth(),
                                            contentPadding = PaddingValues(horizontal = 16.dp)
                                        ) {
                                            items(forecastState.data?.list ?: emptyList()) { item ->
                                                ForecastItem(forecast = item)
                                            }
                                        }
                                    }
                                    is Resource.Error -> {
                                        Text(
                                            text = "Failed to load forecast: ${forecastState.message}",
                                            color = Color.Red,
                                            modifier = Modifier.padding(24.dp)
                                        )
                                    }
                                    is Resource.Loading -> {
                                        Box(modifier = Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                }
                            }
                        }
                        is Resource.Error -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "Oops! ${weatherState.message}", color = Color.White, modifier = Modifier.padding(24.dp))
                                    Button(onClick = { fetchWeatherWithLocation() }) {
                                        Text("Try Again")
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(100.dp)) // Extra space for FAB
            }
        }
    }
}
