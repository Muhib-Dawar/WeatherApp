package com.example.weatherapp.presentation.screens.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.weatherapp.WeatherApplication
import com.example.weatherapp.presentation.components.ForecastItem
import com.example.weatherapp.presentation.components.WeatherCard
import com.example.weatherapp.presentation.viewmodel.DetailViewModel
import com.example.weatherapp.util.Resource

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    navController: NavController,
    cityName: String
) {
    val context = LocalContext.current
    val app = context.applicationContext as WeatherApplication
    val viewModel: DetailViewModel = viewModel {
        DetailViewModel(app.di.repository, cityName)
    }
    
    val weatherState by viewModel.weatherState
    val forecastState by viewModel.forecastState
    val isFavorite by viewModel.isFavorite

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("City Weather") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    val weatherData = weatherState.data
                    if (weatherData != null) {
                        IconButton(onClick = { viewModel.toggleFavorite(weatherData.sys.country) }) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isFavorite) Color.Red else Color.Gray
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (weatherState) {
                is Resource.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is Resource.Success -> {
                    weatherState.data?.let { weather ->
                        WeatherCard(weather = weather)

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Forecast",
                            modifier = Modifier.padding(horizontal = 16.dp),
                            style = MaterialTheme.typography.titleMedium
                        )

                        when (forecastState) {
                            is Resource.Success -> {
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentPadding = PaddingValues(8.dp)
                                ) {
                                    items(forecastState.data?.list ?: emptyList()) { item ->
                                        ForecastItem(forecast = item)
                                    }
                                }
                            }
                            is Resource.Error -> {
                                Text(text = "Error loading forecast", color = Color.Red, modifier = Modifier.padding(16.dp))
                            }
                            else -> { /* Loading */ }
                        }
                    }
                }
                is Resource.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = weatherState.message ?: "Error", color = Color.Red)
                    }
                }
            }
        }
    }
}
