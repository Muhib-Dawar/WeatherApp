package com.example.weatherapp.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteCityDao {
    @Query("SELECT * FROM favorite_cities ORDER BY addedAt DESC")
    fun getAllFavoriteCities(): Flow<List<FavoriteCityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCity(city: FavoriteCityEntity)

    @Delete
    suspend fun deleteCity(city: FavoriteCityEntity)

    @Query("SELECT EXISTS(SELECT * FROM favorite_cities WHERE cityName = :cityName)")
    suspend fun isCityFavorite(cityName: String): Boolean
}
